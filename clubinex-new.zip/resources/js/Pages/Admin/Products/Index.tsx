import { Head, router } from '@inertiajs/react';
import { Plus, RefreshCw, Box, FileText } from 'lucide-react';
import React, { useState, useEffect } from 'react';
import Pagination from '@/Components/Pagination';
import SearchInput from '@/Components/SearchInput';
import DashboardLayout from '@/Layouts/DashboardLayout';
import type {
    PageProps,
    PaginatedData,
    Product,
    ProductRegistration,
} from '@/types';

import CreateProductModal from './Partials/CreateProductModal';
import ImportSerialsModal from './Partials/ImportSerialsModal';
import ManageSerialsModal from './Partials/ManageSerialsModal';
import ProductTable from './Partials/ProductTable';
import RegistrationReviewModal from './Partials/RegistrationReviewModal';
import RegistrationTable from './Partials/RegistrationTable';
import WpProductSyncModal from './Partials/WpProductSyncModal';

interface Category {
    id: number;
    title: string;
}

interface FilterParams {
    search?: string;
}

interface Props extends PageProps {
    products: PaginatedData<Product>;
    registrations: PaginatedData<ProductRegistration>;
    categories: Category[];
    filters: FilterParams;
}

export default function AdminProductsIndex({
    products,
    registrations,
    categories,
    filters,
}: Props) {
    const params = new URLSearchParams(window.location.search);
    const initialTab =
        (params.get('tab') as 'inventory' | 'registrations') || 'inventory';

    const [activeTab, setActiveTab] = useState<'inventory' | 'registrations'>(
        initialTab,
    );
    const [searchQuery, setSearchQuery] = useState(filters?.search || '');
    const [isLoading, setIsLoading] = useState(false);

    // Modals State
    const [showProductModal, setShowProductModal] = useState(false);
    const [showImportModal, setShowImportModal] = useState(false);
    const [showWpModal, setShowWpModal] = useState(false);
    const [showSerialModal, setShowSerialModal] = useState(false);
    const [showReviewModal, setShowReviewModal] = useState(false);

    const [selectedProduct, setSelectedProduct] = useState<Product | null>(
        null,
    );
    const [selectedRegistration, setSelectedRegistration] =
        useState<ProductRegistration | null>(null);

    // همگام‌سازی استیت جستجو با فیلترهای دریافتی از سرور (برای دکمه‌های بازگشت مرورگر)
    useEffect(() => {
        setSearchQuery(filters?.search || '');
    }, [filters?.search]);

    // همگام‌سازی تب با URL
    useEffect(() => {
        const currentTab = params.get('tab');
        if (
            currentTab &&
            (currentTab === 'inventory' || currentTab === 'registrations')
        ) {
            setActiveTab(currentTab);
        }
    }, []);

    const performSearch = (query: string) => {
        setIsLoading(true);

        // هنگام جستجو، صفحه را به 1 برمی‌گردانیم (رفتار طبیعی جستجو)
        router.get(
            route('admin.products.index'),
            { tab: activeTab, search: query },
            {
                preserveState: true,
                preserveScroll: true,
                onFinish: () => setIsLoading(false),
                replace: true,

            },
        );
    };

    const switchTab = (tab: 'inventory' | 'registrations') => {
        setActiveTab(tab);
        // هنگام تغییر تب، جستجو حفظ می‌شود اما صفحه ریست می‌شود
        router.get(
            route('admin.products.index'),
            { tab: tab, search: searchQuery },
            { preserveState: true, preserveScroll: true },
        );
    };

    // --- Actions ---

    const openCreateModal = () => {
        setSelectedProduct(null);
        setShowProductModal(true);
    };

    const openEditModal = (product: Product) => {
        setSelectedProduct(product);
        setShowProductModal(true);
    };

    const openImportModal = (product: Product) => {
        setSelectedProduct(product);
        setShowImportModal(true);
    };

    const openSerialModal = (product: Product) => {
        setSelectedProduct(product);
        setShowSerialModal(true);
    };

    const openReviewModal = (reg: ProductRegistration) => {
        setSelectedRegistration(reg);
        setShowReviewModal(true);
    };

    const handleDelete = (id: number) => {
        if (
            confirm(
                'آیا از حذف این محصول اطمینان دارید؟ توجه: اگر محصول سریال استفاده شده داشته باشد حذف نمی‌شود.',
            )
        ) {
            router.delete(route('admin.products.destroy', id), {
                preserveScroll: true,
            });
        }
    };

    return (
        <DashboardLayout breadcrumbs={[{ label: 'مدیریت محصولات' }]}>
            <Head title="مدیریت محصولات" />

            <div className="mb-6 flex flex-col items-start justify-between gap-4 md:flex-row md:items-center">
                <h1 className="text-2xl font-black tracking-tight text-gray-800">
                    مدیریت محصولات و درخواست‌ها
                </h1>

                <div className="flex gap-2">
                    <button
                        onClick={() => setShowWpModal(true)}
                        className="flex items-center justify-center gap-2 rounded-xl border border-gray-200 bg-white px-4 py-2.5 text-sm font-medium text-gray-700 shadow-sm transition hover:bg-gray-50"
                    >
                        <RefreshCw size={18} />
                        وردپرس
                    </button>
                    <button
                        onClick={openCreateModal}
                        className="flex items-center justify-center gap-2 rounded-xl bg-primary-600 px-4 py-2.5 text-sm font-bold text-white shadow-lg shadow-primary-500/30 transition hover:bg-primary-700"
                    >
                        <Plus size={20} />
                        افزودن
                    </button>
                </div>
            </div>

            {/* Filter & Search Bar */}
            <div className="mb-6 flex flex-col items-end gap-3 rounded-2xl border border-gray-100 bg-white p-4 shadow-sm md:flex-row md:items-center">
                <div className="relative w-full flex-1">
                    <SearchInput
                        value={searchQuery}
                        onChange={setSearchQuery}
                        onSearch={performSearch}
                        placeholder="جستجو در نام محصول، مدل، سریال یا نام/موبایل کاربر..."
                        loading={isLoading}
                    />
                </div>

                <div className="flex rounded-xl bg-gray-100 p-1">
                    <button
                        onClick={() => switchTab('inventory')}
                        className={`flex items-center gap-2 rounded-lg px-4 py-2 text-xs font-bold transition-all ${activeTab === 'inventory' ? 'bg-white text-primary-700 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
                    >
                        <Box size={16} />
                        موجودی
                    </button>
                    <button
                        onClick={() => switchTab('registrations')}
                        className={`flex items-center gap-2 rounded-lg px-4 py-2 text-xs font-bold transition-all ${activeTab === 'registrations' ? 'bg-white text-primary-700 shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
                    >
                        <FileText size={16} />
                        درخواست‌ها
                        {registrations?.data?.filter(
                            (r) => r.status === 'pending',
                        ).length > 0 && (
                            <span className="animate-pulse rounded-full bg-red-500 px-1.5 py-0.5 text-[9px] text-white">
                                {
                                    registrations.data.filter(
                                        (r) => r.status === 'pending',
                                    ).length
                                }
                            </span>
                        )}
                    </button>
                </div>
            </div>

            {/* Content Based on Tab */}
            {activeTab === 'inventory' && products?.data && (
                <>
                    <ProductTable
                        products={products as PaginatedData<Product>}
                        onImportSerial={openImportModal}
                        onEdit={openEditModal}
                        onDelete={handleDelete}
                        onManageSerials={openSerialModal}
                    />
                    <Pagination links={(products as PaginatedData<Product>).links} />
                </>
            )}

            {activeTab === 'registrations' && registrations?.data && (
                <>
                    <RegistrationTable
                        registrations={registrations as PaginatedData<ProductRegistration>}
                        onReview={openReviewModal}
                    />
                    <Pagination links={(registrations as PaginatedData<ProductRegistration>).links} />
                </>
            )}

            {/* Modals */}
            <CreateProductModal
                isOpen={showProductModal}
                onClose={() => setShowProductModal(false)}
                categories={categories}
                product={selectedProduct}
            />

            <ImportSerialsModal
                isOpen={showImportModal}
                onClose={() => setShowImportModal(false)}
                selectedProduct={selectedProduct}
            />

            <ManageSerialsModal
                isOpen={showSerialModal}
                onClose={() => setShowSerialModal(false)}
                productId={selectedProduct?.id}
                productTitle={selectedProduct?.title}
            />

            <WpProductSyncModal
                isOpen={showWpModal}
                onClose={() => setShowWpModal(false)}
            />

            <RegistrationReviewModal
                isOpen={showReviewModal}
                onClose={() => setShowReviewModal(false)}
                registration={selectedRegistration}
            />
        </DashboardLayout>
    );
}
