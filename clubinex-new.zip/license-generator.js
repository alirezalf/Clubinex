import crypto from 'crypto';
import readline from 'readline';

// Offline Private Key
const PRIVATE_KEY = `-----BEGIN PRIVATE KEY-----
MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCjTeGb5haI6f7L
sWGjpwuVyJvvD5Bh7sXT7ZeECqtirfljKtu8DAEYKw1w5MdvQcbUw+LOp5OZ2dFh
0lz2WyBJpPRHKWFmF8hCXukf2vu2hqPbgGl9hKtoICsOfZ/AhA7RzVuapn5CJQId
S01C/kBXGnbwZMATPLEteG2MvaheflUA46oM8e5xNxXKuOKOk4rscQOhZz8XsVo/
HxGYSj21J3Yp9M5SyUQWdHijRXUFJJ/hW1nIF0ydKAm8oZ6EFVvNhlzIXadVCO28
mibmFCEz+I5CAHaIhC+jEAD5Nj7hZ6vAaVPQ9gwk985KCN0qf0fwEbEnkV5qYf/C
pH2TupclAgMBAAECggEAJR+22pyHYe+j80VrV2tJqG7W+BU3MvQ3d9Kq36MXTBMV
vxQGqOynsQlUgGYZ6nJvE35GiMkytkZ8oXrTlFOp9uPvfl/rWuysI151K785+sgH
5wX9tUGcP8sUTrKDRx4eSlafbPxNdpb4MJWmRkULdmG3STX2LkldU+NtMBILfRNo
3yJw6NqBlCfuPqj+2SRB6RsATEymqNSXzD3oVclBSMkb2zpQew/V26oI37Q/5Y/i
9WAiYxP3lkTBGfxbfSS8yYszZbHbhlTLNCu0zsHHHx6RK+3AWvUcuUP+DpEPeMKi
903T4jValH8030Kjmn4GO6NfTDG7TAKIxsTzWThlIQKBgQDcnlNKgPPROewq5Fwp
LFCGivkRpceNkvmS3MfOAN4bs2LzGQ1vg9ioxWjbyQHIcZ0HwUYlfHvwSjUvjwIB
3gsQM8tIKU6GqB2xcW0AGZiT4USgnYiWcdK6/iRAeD2tr62z2xRMAZUilZPspSEN
16WPADuhgEixxDd8WCp2nRTJ1QKBgQC9fnjmjFIQAhOxfXb/KVDSnNqyftEAJdrq
bnxVu7yrBeBNjXXA0Dkg8JCkcX9zq20folG+bOJXLHYqn+Y5wsHyn1daDzL8EpOG
TRo3YYRyQMuD9XhPAm9gI3PNCajCplqQlZ2OdHfYu2QHnEVY9x3+tJQ5z4acRzdP
SUivMtxwEQKBgD9Ijx3M9aNrmQoIrUMGOicN0Do2spIyubJd8FZwO0X45AZVhlwZ
ltl6nwSEmSVVKbUixKtWFPstXipBPFMqzUOdh88wQh0wNixDHAAuV2z77kKgTaDS
D5+h7OYtV4vt28a+rgjLX2snOuJjz6J33D6z02cVNEUBwuTBKZUSo/btAoGBAK+W
HINM7NGGiycBIh2n9AtkasXQ+usPKL3n6PAsSNOUW1ahSMaEaxtZrj2iKb5Nz4zr
hKFWFZk/SrOOfO9yxvKBsZhy0wR+VhKxKSS+CNMxtSMudu+HSxqjXy9Tzvum1+53
pIoW4+KBKVxf8mZQfYvBWkQDRzFSUC74shAdqeNxAoGABzED077GM3/4WQQOCF6x
lzRb9081G915mGmPp+tUjsjyWA+4T9mvLu5DkewIYFEO3mSJbHvmFFFbYwVLZMm6
f/l0u85phgmX4fcv2EKsi6GnG0IbBYWoxhAQ0krYdFNe6BeaakWpwlZYiAaQbckW
ZdLXSsYwum5P6rzYdqkCchE=
-----END PRIVATE KEY-----`;

function base64UrlEncode(str) {
    return Buffer.from(str)
        .toString('base64')
        .replace(/=/g, '')
        .replace(/\+/g, '-')
        .replace(/\//g, '_');
}

function generateJWT(payload) {
    const header = { alg: 'RS256', typ: 'JWT' };
    const encodedHeader = base64UrlEncode(JSON.stringify(header));
    const encodedPayload = base64UrlEncode(JSON.stringify(payload));

    const signatureTarget = `${encodedHeader}.${encodedPayload}`;
    const signer = crypto.createSign('RSA-SHA256');
    signer.update(signatureTarget);
    const signature = signer.sign(PRIVATE_KEY, 'base64')
        .replace(/=/g, '')
        .replace(/\+/g, '-')
        .replace(/\//g, '_');

    return `${signatureTarget}.${signature}`;
}

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

const questions = [
    { key: 'client_name', text: 'Enter Client/Company Name: ' },
    { key: 'machine_id', text: 'Enter Machine ID (as seen in admin panel): ' },
    { key: 'months', text: 'Enter Expiry in Months (e.g., 12): ', default: '12' },
];

const availableModules = [
    'enable_clubs', 'enable_lucky_wheel', 'enable_products',
    'enable_rewards', 'enable_wallet', 'enable_referrals',
    'enable_surveys', 'enable_tickets', 'enable_reports'
];

async function askQuestion(query) {
    return new Promise(resolve => rl.question(query, resolve));
}

async function main() {
    console.log('\n================================');
    console.log('   CLUBINEX LICENSE GENERATOR   ');
    console.log('================================\n');

    const answers = {};
    for (const q of questions) {
        let res = await askQuestion(q.text);
        if (!res && q.default) res = q.default;
        answers[q.key] = res;
    }

    console.log('\n--- MODULE CONFIGURATION ---');
    console.log('Enter 1 to enable, or 0 to disable each module (Default: 1)');
    const modules = {};
    for (const mod of availableModules) {
        let res = await askQuestion(`${mod} (1/0): `);
        modules[mod] = res === '0' ? false : true;
    }

    const expTimestamp = Math.floor(Date.now() / 1000) + (parseInt(answers.months) * 30 * 24 * 60 * 60);

    const payload = {
        client_name: answers.client_name,
        machine_id: (answers.machine_id || '').trim(),
        exp: expTimestamp,
        iat: Math.floor(Date.now() / 1000),
        iss: "Clubinex_License_Server",
        modules: modules
    };

    const token = generateJWT(payload);

    console.log('\n================================');
    console.log('LICENSE GENERATED SUCCESSFULLY:');
    console.log('================================\n');
    console.log(token);
    console.log('\n================================\n');

    rl.close();
}

main();
