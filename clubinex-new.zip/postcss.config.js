export default {
    plugins: {
        autoprefixer: {},
    },
};