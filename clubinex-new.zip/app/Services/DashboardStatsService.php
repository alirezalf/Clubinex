<?php

namespace App\Services;

use App\Models\User;
use App\Models\Club;
use App\Models\ActivityLog;
use App\Models\RewardRedemption;
use App\Models\PointTransaction;
use App\Models\PointRule;
use App\Models\UserSession;
use Illuminate\Support\Facades\DB;

class DashboardStatsService
{
    /**
     * مدیریت پاداش‌های ورود روزانه و استریک ماهانه
     * بهینه‌سازی شده برای جلوگیری از کوئری‌های سنگین تکراری
     */
    public function handleDailyRewards(User $user)
    {
        // Cache checking to reduce DB hits on every page load
        $cacheKey = "daily_rewards_checked_{$user->id}_" . date('Y-m-d');

        if (cache()->has($cacheKey)) {
            return;
        }

        // 1. پاداش بازدید روزانه
        $visitRule = PointRule::where('action_code', 'visit_site')->active()->first();
        if ($visitRule) {
            $hasVisitedToday = PointTransaction::where('user_id', $user->id)
                ->where('point_rule_id', $visitRule->id)
                ->whereDate('created_at', today())
                ->exists();

            if (!$hasVisitedToday) {
                $maxDaily = 1000;
                $todayEarned = PointTransaction::where('user_id', $user->id)
                    ->earned()
                    ->whereDate('created_at', today())
                    ->sum('amount');

                if ($todayEarned < $maxDaily) {
                    PointTransaction::awardPoints(
                        $user->id,
                        $visitRule->points,
                        $visitRule->id,
                        'امتیاز بازدید روزانه'
                    );
                }
            }
        }

        // 2. پاداش وفاداری ماهانه (۳۰ روز بازدید)
        $streakRule = PointRule::where('action_code', 'monthly_streak')->active()->first();
        if ($streakRule) {
            $recentlyRewarded = PointTransaction::where('user_id', $user->id)
                ->where('point_rule_id', $streakRule->id)
                ->where('created_at', '>=', now()->subDays(5))
                ->exists();

            if (!$recentlyRewarded) {
                // Optimized: Use database to count distinct dates, significantly reduces PHP memory usage
                $daysCount = DB::table('point_transactions')
                    ->where('user_id', $user->id)
                    ->where('created_at', '>=', now()->subDays(30))
                    ->selectRaw('COUNT(DISTINCT DATE(created_at)) as days_count')
                    ->value('days_count');

                if ($daysCount >= 30) {
                    PointTransaction::awardPoints(
                        $user->id,
                        $streakRule->points,
                        $streakRule->id,
                        'پاداش وفاداری ماهانه (۳۰ روز بازدید)'
                    );
                }
            }
        }

        // ثبت در کش برای جلوگیری از اجرای مجدد در همین روز
        cache()->put($cacheKey, true, now()->endOfDay());
    }

    public function getAdminStats()
    {
        return cache()->remember('admin_dashboard_stats', 300, function () {

            // Average points (Limit to active users to avoid massive scan)
            $avgPoints = User::where('last_login_at', '>=', now()->subDays(30))->avg('current_points') ?? 0;

            // Inflation calculation (Only calculate for last 6 months to avoid full table scan)
            $sixMonthsAgo = now()->subMonths(6);
            $totalDistributedPoints = PointTransaction::earned()
                ->where('created_at', '>=', $sixMonthsAgo)
                ->sum('amount');
            $totalRedeemedPoints = RewardRedemption::whereIn('status', ['completed', 'shipped', 'delivered', 'processing'])
                ->where('created_at', '>=', $sixMonthsAgo)
                ->sum('points_spent');
            $totalRedeemedRewardsCashValue = RewardRedemption::whereIn('reward_redemptions.status', ['completed', 'shipped', 'delivered', 'processing'])
                ->where('reward_redemptions.created_at', '>=', $sixMonthsAgo)
                ->join('rewards', 'reward_redemptions.reward_id', '=', 'rewards.id')
                ->sum('rewards.cash_cost');

            $pointRealValue = $totalDistributedPoints > 0
                ? ($totalRedeemedRewardsCashValue > 0 ? round($totalRedeemedRewardsCashValue / $totalDistributedPoints, 2) : 0)
                : 0;

            // Most active hours (busiest hour) - Limit to recent activities
            $busiestHourData = DB::table('activity_logs')
               ->where('created_at', '>=', now()->subDays(30))
               ->select(DB::raw('HOUR(created_at) as hour'), DB::raw('count(*) as count'))
               ->groupBy('hour')
               ->orderByDesc('count')
               ->first();
            $busiestHourStr = $busiestHourData ? 'ساعت ' . $busiestHourData->hour . ' تا ' . ($busiestHourData->hour + 1) : 'نامشخص';

            // Retention rate (Users returning after 1 day of creation)
            $totalUsers = User::count();
            // Count users active in last 30 days
            $returningUsers = User::where('last_login_at', '>=', now()->subDays(30))->count();

            $retentionRate = $totalUsers > 0 ? round(($returningUsers / $totalUsers) * 100) : 0;

            $openTickets = \App\Models\Ticket::whereIn('status', ['open', 'pending', 'customer_reply'])->count();
            $pendingWithdrawals = \App\Models\WalletWithdrawal::where('status', 'pending')->count();

            return [
                'total_users' => $totalUsers,
                'new_users_today' => User::whereDate('created_at', today())->count(),
                'pending_rewards' => RewardRedemption::where('status', 'pending')->count(),
                'total_points_distributed' => $totalDistributedPoints,
                'avg_points' => round($avgPoints),
                'busiest_hour' => $busiestHourStr,
                'retention_rate' => $retentionRate,
                'point_real_value' => $pointRealValue,
                'total_redeemed_points' => $totalRedeemedPoints,
                'open_tickets' => $openTickets,
                'pending_withdrawals' => $pendingWithdrawals,
            ];
        });
    }

    /**
     * دریافت لیست برترین‌ها (لیدربورد) با کش دوره‌ای (مثلا یک ساعته)
     */
    public function getLeaderboard($limit = 10)
    {
        return cache()->remember("leaderboard_top_{$limit}", 3600, function () use ($limit) {
            return User::active()
                ->select('id', 'first_name', 'last_name', 'avatar', 'current_points', 'club_id')
                ->with('club:id,name,color,icon')
                ->orderBy('current_points', 'desc')
                ->take($limit)
                ->get()
                ->map(function ($u) {
                    return [
                        'id' => $u->id,
                        'name' => $u->full_name,
                        'points' => $u->current_points, // We don't use cached property here for batch loading efficiency
                        'avatar' => $u->avatar,
                        'club_name' => $u->club ? $u->club->name : 'بدون سطح',
                        'club_icon' => $u->club ? $u->club->icon : null,
                        'club_color' => $u->club ? $u->club->color : null,
                    ];
                });
        });
    }

    public function getUserStats(User $user)
    {
        if (!$user->relationLoaded('club')) {
            $user->load('club');
        }

        $currentClub = $user->club;

        $nextClub = cache()->remember("club_next_tier_" . ($currentClub ? $currentClub->id : 'none'), 3600, function () use ($currentClub) {
            return $currentClub ? $currentClub->getNextTier() : Club::tiers()->orderBy('min_points')->first();
        });

        $progress = 100;
        $pointsNeeded = 0;

        if ($nextClub) {
            $minPoints = $currentClub ? $currentClub->min_points : 0;
            $range = $nextClub->min_points - $minPoints;

            if ($range > 0) {
                $currentInLevel = $user->current_points - $minPoints;
                $progress = min(100, max(0, ($currentInLevel / $range) * 100));
            }

            $pointsNeeded = max(0, $nextClub->min_points - $user->current_points);
        }

        return [
            'points' => (int) ($user->current_points ?? 0),
            'referrals' => cache()->remember("user_referrals_count_{$user->id}", 3600, function() use ($user) {
                return $user->getDirectReferralsCountAttribute();
            }),
            'club' => $currentClub ? $currentClub->name : 'سطح پایه',
            'club_color' => $currentClub ? $currentClub->color : '#64748b',
            'club_icon' => $currentClub ? $currentClub->icon : 'star',
            'next_club' => $nextClub ? $nextClub->name : 'بالاترین سطح',
            'progress_percent' => round($progress),
            'points_needed' => $pointsNeeded
        ];
    }

    public function getRecentActivities()
    {
        return cache()->remember('recent_activities', 60, function () {
            return ActivityLog::with('user')
                ->latest()
                ->take(6)
                ->get()
                ->map(function ($log) {
                    return [
                        'id' => $log->id,
                        'user' => $log->user ? $log->user->full_name : 'سیستم',
                        'description' => $log->description,
                        'time' => $log->created_at->diffForHumans(),
                        'action_group' => $log->action_group
                    ];
                });
        });
    }

    public function getQuickAccessItems(User $user)
    {
        $prefs = is_array($user->dashboard_preferences) ? $user->dashboard_preferences : [];
        $pinned = $prefs['quick_access'] ?? [];

        $frequent = cache()->remember("user_frequent_pages_{$user->id}", 3600, function () use ($user) {
            return UserSession::where('user_id', $user->id)
                ->select('page_url', DB::raw('count(*) as total'))
                ->groupBy('page_url')
                ->orderByDesc('total')
                ->take(5)
                ->get()
                ->map(function($session) {
                    if (str_contains($session->page_url, 'rewards')) return 'rewards';
                    if (str_contains($session->page_url, 'lucky-wheel')) return 'lucky_wheel';
                    if (str_contains($session->page_url, 'products')) return 'products';
                    if (str_contains($session->page_url, 'surveys')) return 'surveys';
                    if (str_contains($session->page_url, 'tickets')) return 'tickets';
                    if (str_contains($session->page_url, 'profile')) return 'profile';
                    if (str_contains($session->page_url, 'referrals')) return 'referrals';
                    return null;
                })
                ->filter()
                ->unique()
                ->values()
                ->toArray();
        });

        return [
            'pinned' => $pinned,
            'frequent' => $frequent
        ];
    }
}
