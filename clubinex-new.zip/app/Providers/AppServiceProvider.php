<?php

namespace App\Providers;

use App\Models\SystemSetting;
use Illuminate\Support\Facades\View;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Http\Request;
use Illuminate\Cache\RateLimiting\Limit;
use Inertia\Inertia;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        // Fix for shared hosting where public directory might be renamed (e.g. public_html)
        if (!app()->runningInConsole() && isset($_SERVER['SCRIPT_FILENAME'])) {
            app()->usePublicPath(dirname($_SERVER['SCRIPT_FILENAME']));
        }
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        // Self-healing storage symlink (معادل artisan storage:link)
        // اگر لینک public/storage وجود نداشته باشد، فایل‌های آپلودی (آواتار، عکس محصول،
        // فاکتور، لوگو و ...) با خطای 404 نمایش داده می‌شوند. این کد به صورت خودکار آن را می‌سازد.
        try {
            $publicStorage = public_path('storage');
            if (!file_exists($publicStorage)) {
                @symlink(storage_path('app/public'), $publicStorage);
                if (!file_exists($publicStorage)) {
                    // هاست‌هایی که symlink را نمی‌پذیرند: کپی یک‌باره محتویات
                    @mkdir($publicStorage, 0755, true);
                    if (is_dir(storage_path('app/public'))) {
                        foreach (\Illuminate\Support\Facades\File::allFiles(storage_path('app/public')) as $file) {
                            $target = $publicStorage . '/' . $file->getRelativePathname();
                            @mkdir(dirname($target), 0755, true);
                            @copy($file->getPathname(), $target);
                        }
                    }
                }
            }
        } catch (\Throwable $e) {
            // silent - never block boot
        }

        // Rate Limiting
        RateLimiter::for('api', function (Request $request) {
            return Limit::perMinute(60)->by($request->user()?->id ?: $request->ip());
        });

        RateLimiter::for('login', function (Request $request) {
            return Limit::perMinute(5)->by($request->ip());
        });

        RateLimiter::for('register', function (Request $request) {
            return Limit::perHour(10)->by($request->ip());
        });

        // Force HTTPS if APP_URL starts with https:// or if request is secure (Fixes Laragon SSL + VPN issues)
        if (str_starts_with(config('app.url'), 'https://') || (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on')) {
            \Illuminate\Support\Facades\URL::forceScheme('https');
        }

        // Force Sync Queue in Local Environment
        if (app()->isLocal()) {
            config(['queue.default' => 'sync']);
        }

        try {
            // جلوگیری از خطا در هنگام اجرای مایگریشن اولیه یا عدم وجود دیتابیس
            if (!Schema::hasTable('system_settings')) {
                return;
            }

            // Runtime Migration Fix for sms_template_id
            if (Schema::hasTable('notification_broadcasts') && !Schema::hasColumn('notification_broadcasts', 'sms_template_id')) {
                Schema::table('notification_broadcasts', function (\Illuminate\Database\Schema\Blueprint $table) {
                    $table->foreignId('sms_template_id')->nullable()->constrained('sms_templates')->nullOnDelete();
                });
            }

            // کش کردن تنظیمات برای جلوگیری از کوئری تکراری در هر درخواست
            $settings = cache()->remember('global_settings', 3600, function () {
                return SystemSetting::getSettingsArray();
            });

            // تنظیمات ایمیل
            if (!empty($settings['mail_host'])) {
                config([
                    'mail.default' => 'smtp',
                    'mail.mailers.smtp.host' => $settings['mail_host'],
                    'mail.mailers.smtp.port' => $settings['mail_port'],
                    'mail.mailers.smtp.encryption' => (int)$settings['mail_port'] === 465 ? 'ssl' : 'tls',
                    'mail.mailers.smtp.username' => $settings['mail_username'],
                    'mail.mailers.smtp.password' => $settings['mail_password'],
                    'mail.from.address' => $settings['mail_from_address'],
                    'mail.from.name' => $settings['mail_from_name'],
                    'mail.mailers.smtp.stream' => [
                        'ssl' => [
                            'allow_self_signed' => true,
                            'verify_peer' => false,
                            'verify_peer_name' => false,
                        ],
                    ],
                ]);
            }

            // مدیریت رنگ‌ها
            $primaryColor = $settings['theme.primary_color'] ?? '#0284c7';
            if (!str_starts_with($primaryColor, '#')) {
                $primaryColor = '#' . $primaryColor;
            }

            // تبدیل به RGB برای استفاده در CSS Variables
            // مقادیر پیش‌فرض در صورت خطا
            $r = 2; $g = 132; $b = 199;

            try {
                if (preg_match('/^#([a-f0-9]{6})$/i', $primaryColor)) {
                    list($r, $g, $b) = sscanf($primaryColor, "#%02x%02x%02x");
                }
            } catch (\Exception $e) {
                // رنگ پیش‌فرض در صورت فرمت نامعتبر
            }

            $themeData = [
                'primary_color' => $primaryColor,
                'primary_rgb' => "$r $g $b", // ارسال مقدار RGB محاسبه شده
                'radius_size' => $settings['theme.radius_size'] ?? '0.75rem',
                'sidebar_bg' => $settings['theme.sidebar_bg'] ?? '#ffffff',
                'sidebar_text' => $settings['theme.sidebar_text'] ?? '#1f2937',
                'sidebar_texture' => $settings['theme.sidebar_texture'] ?? 'none',
                'header_bg' => $settings['theme.header_bg'] ?? 'rgba(255,255,255,0.8)',
                'sidebar_collapsed' => filter_var($settings['theme.sidebar_collapsed'] ?? false, FILTER_VALIDATE_BOOLEAN),
            ];

            // اشتراک‌گذاری تنظیمات مهم با ویوی اصلی بلید (برای CSS Variables اولیه)
            View::share('themeSettings', $themeData);

            // اشتراک‌گذاری اطلاعات عمومی سایت با Inertia (برای استفاده در کامپوننت‌های React)
            Inertia::share([
                'themeSettings' => $themeData, // ارسال تنظیمات تم به ری‌اکت
                'site' => [
                    'name' => $settings['general.site_title'] ?? 'Clubinex',
                    'description' => $settings['general.site_description'] ?? '',
                    'logo' => $settings['theme.logo_url'] ?? null,
                    'favicon' => $settings['theme.favicon_url'] ?? null,
                    'socials' => [
                        'instagram' => $settings['social.instagram'] ?? null,
                        'telegram' => $settings['social.telegram'] ?? null,
                        'whatsapp' => $settings['social.whatsapp'] ?? null,
                        'linkedin' => $settings['social.linkedin'] ?? null,
                    ],
                    'contact' => [
                        'phone' => $settings['contact.admin_mobile'] ?? '',
                        'email' => $settings['contact.support_email'] ?? '',
                        'address' => $settings['contact.address'] ?? '',
                    ]
                ]
            ]);
        } catch (\Exception $e) {
            // در صورت خطای دیتابیس، مقادیر پیش‌فرض را ست می‌کنیم تا بیلد شکست نخورد
            $defaultTheme = [
                'primary_color' => '#0284c7',
                'primary_rgb' => '2 132 199',
                'radius_size' => '0.75rem',
                'header_bg' => '#ffffff',
                'sidebar_collapsed' => false
            ];
            View::share('themeSettings', $defaultTheme);
            Inertia::share(['themeSettings' => $defaultTheme]);
        }
    }
}
