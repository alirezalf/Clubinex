<?php

namespace App\Http\Middleware;

use Illuminate\Http\Request;
use Inertia\Middleware;
use Tighten\Ziggy\Ziggy;
use App\Models\Ticket;
use App\Models\SystemSetting;
use App\Models\Slider;
use Illuminate\Support\Facades\Route;

use App\Services\ThemeService;

class HandleInertiaRequests extends Middleware
{
    protected $rootView = 'app';
    protected $themeService;

    public function __construct(ThemeService $themeService)
    {
        $this->themeService = $themeService;
    }

    public function handle(Request $request, \Closure $next)
    {
        $response = parent::handle($request, $next);

        $response->headers->set('Cache-Control', 'no-cache, no-store, max-age=0, must-revalidate');
        $response->headers->set('Pragma', 'no-cache');
        $response->headers->set('Expires', 'Sat, 01 Jan 2000 00:00:00 GMT');

        return $response;
    }

    public function version(Request $request): ?string
    {
        return parent::version($request);
    }

    public function share(Request $request): array
    {
        $user = $request->user();

        // 1. Theme Settings via Service
        $activeTheme = $this->themeService->getActiveTheme($user);

        return array_merge(parent::share($request), [
            'auth' => [
                'user' => $user ? [
                    'id' => $user->id,
                    'first_name' => $user->first_name,
                    'last_name' => $user->last_name,
                    'mobile' => $user->mobile,
                    'avatar' => $user->avatar,
                    'roles' => $user->getRoleNames(),
                    'points' => $user->current_points,
                ] : null,
            ],
            // 2. Badges & Notifications (Lazy Evaluation)
            'unreadNotificationsCount' => fn () => $user ? $user->unreadNotifications()->count() : 0,
            'badges' => fn () => $this->getBadges($user),
            'themeSettings' => $activeTheme,
            // 4. Login Settings (Lazy Evaluation)
            'loginSettings' => fn () => \Illuminate\Support\Facades\Cache::remember('login_settings', 3600, function () {
                return SystemSetting::where('group', 'login')->pluck('value', 'key')->toArray();
            }),
            'site' => fn () => \Illuminate\Support\Facades\Cache::remember('site_settings', 3600, function () {
                $general = SystemSetting::where('group', 'general')->pluck('value', 'key')->toArray();
                return [
                    'name' => $general['app_name'] ?? $general['site_title'] ?? $general['site_name'] ?? 'Clubinex',
                    'logo' => $general['site_logo'] ?? null,
                    'version' => $general['app_version'] ?? $general['version'] ?? '2.0',
                ];
            }),
            'modules' => fn () => \Illuminate\Support\Facades\Cache::remember('modules_settings', 3600, function () {
                $dbModules = SystemSetting::where('group', 'modules')->pluck('value', 'key')->toArray();
                $licenseKey = SystemSetting::getValue('general', 'license_key');
                $licenseModules = [];
                if ($licenseKey) {
                    $payload = \App\Services\LicenseService::verifyLicense($licenseKey);
                    if ($payload) {
                        $licenseModules = $payload['modules'] ?? [];
                    }
                }

                $effectiveModules = [];
                // All known modules
                $moduleKeys = [
                    'enable_referrals', 'enable_wallet', 'enable_clubs',
                    'enable_products', 'enable_rewards', 'enable_lucky_wheel',
                    'enable_surveys', 'enable_tickets', 'enable_reports'
                ];
                foreach ($moduleKeys as $k) {
                    $isEnabledInDb = isset($dbModules[$k]) && ($dbModules[$k] === '1' || $dbModules[$k] === true);
                    $isAllowedByLicense = !empty($licenseModules[$k]);
                    $effectiveModules[$k] = $isEnabledInDb && $isAllowedByLicense;
                }
                return $effectiveModules;
            }),
            // 3. دریافت هوشمند اسلایدر برای صفحه جاری (Lazy Evaluation)
            'pageSlider' => fn () => $this->getPageSlider($request),
            'flash' => [
                'message' => fn () => $request->session()->get('message'),
                'error' => fn () => $request->session()->get('error'),
                'success' => fn () => $request->session()->get('success'),
            ],
            // 'ziggy' => function () use ($request) {
            //     return array_merge((new Ziggy)->toArray(), [
            //         'location' => $request->url(),
            //     ]);
            // },
        ]);
    }

    private function getBadges($user)
    {
        $ticketBadges = ['user' => 0, 'admin' => 0, 'rewards' => 0, 'registrations' => 0];

        if ($user) {
            $ticketBadges['user'] = Ticket::where('user_id', $user->id)
                             ->where('status', 'answered')
                             ->count();

            if ($user->hasRole(['super-admin', 'admin', 'staff'])) {
                $query = Ticket::whereIn('status', ['open', 'customer_reply']);
                if (!$user->hasRole('super-admin')) {
                    $query->where('assigned_to', $user->id);
                }
                $ticketBadges['admin'] = $query->count();

                // Count pending reward redemptions
                $ticketBadges['rewards'] = \App\Models\RewardRedemption::where('status', 'pending')->count();

                // Count pending product registrations
                $ticketBadges['registrations'] = \App\Models\ProductRegistration::where('status', 'pending')->count();
            }
        }

        return $ticketBadges;
    }

    private function getPageSlider(Request $request)
    {
        if ($request->isMethod('GET') && !$request->wantsJson()) {
            $currentRoute = Route::currentRouteName();
            if ($currentRoute) {
                return \Illuminate\Support\Facades\Cache::remember("slider_{$currentRoute}", 600, function () use ($currentRoute) {
                    return Slider::with('activeSlides')
                        ->where('location_key', $currentRoute)
                        ->where('is_active', true)
                        ->first();
                });
            }
        }
        return null;
    }
}
