<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use App\Models\SystemSetting;

class SettingSeeder extends Seeder
{
    public function run(): void
    {
        $settings = [
            // تنظیمات عمومی و سئو
            ['group' => 'general', 'key' => 'site_title', 'value' => 'باشگاه مشتریان کلابینکس', 'type' => 'string', 'is_public' => true, 'label' => 'عنوان سایت'],
            ['group' => 'general', 'key' => 'site_description', 'value' => 'بهترین پلتفرم وفاداری مشتریان', 'type' => 'string', 'is_public' => true, 'label' => 'توضیحات سایت'],
            ['group' => 'seo', 'key' => 'meta_keywords', 'value' => 'باشگاه مشتریان, وفاداری, تخفیف, جایزه', 'type' => 'string', 'is_public' => true, 'label' => 'کلمات کلیدی متا'],
            ['group' => 'seo', 'key' => 'og_image', 'value' => '', 'type' => 'string', 'is_public' => true, 'label' => 'تصویر اشتراک‌گذاری (SEO)'], // اضافه شده
            ['group' => 'general', 'key' => 'footer_text', 'value' => 'تمامی حقوق محفوظ است.', 'type' => 'string', 'is_public' => true, 'label' => 'متن فوتر'],

            // اطلاعات تماس
            ['group' => 'contact', 'key' => 'admin_mobile', 'value' => '09196600545', 'type' => 'string', 'is_public' => true, 'label' => 'شماره موبایل مدیر'],
            ['group' => 'contact', 'key' => 'support_email', 'value' => 'support@clubinex.com', 'type' => 'string', 'is_public' => true, 'label' => 'ایمیل پشتیبانی'],
            ['group' => 'contact', 'key' => 'address', 'value' => 'تهران، میدان ونک، خیابان ولیعصر', 'type' => 'string', 'is_public' => true, 'label' => 'آدرس'],

            // شبکه‌های اجتماعی
            ['group' => 'social', 'key' => 'instagram', 'value' => 'https://instagram.com/clubinex', 'type' => 'string', 'is_public' => true, 'label' => 'اینستاگرام'],
            ['group' => 'social', 'key' => 'telegram', 'value' => 'https://t.me/clubinex', 'type' => 'string', 'is_public' => true, 'label' => 'تلگرام'],
            ['group' => 'social', 'key' => 'whatsapp', 'value' => 'https://wa.me/989123456789', 'type' => 'string', 'is_public' => true, 'label' => 'واتساپ'],
            ['group' => 'social', 'key' => 'linkedin', 'value' => 'https://linkedin.com/in/clubinex', 'type' => 'string', 'is_public' => true, 'label' => 'لینکدین'],

            // تنظیمات ظاهری (تم)
            ['group' => 'theme', 'key' => 'primary_color', 'value' => '#0284c7', 'type' => 'string', 'is_public' => true, 'label' => 'رنگ اصلی'],
            ['group' => 'theme', 'key' => 'radius_size', 'value' => '0.75rem', 'type' => 'string', 'is_public' => true, 'label' => 'اندازه گردی گوشه‌ها'],
            ['group' => 'theme', 'key' => 'card_style', 'value' => 'default', 'type' => 'string', 'is_public' => true, 'label' => 'استایل کارت‌ها'],
            ['group' => 'theme', 'key' => 'card_shadow', 'value' => 'sm', 'type' => 'string', 'is_public' => true, 'label' => 'سایه کارت‌ها'], // Added
            ['group' => 'theme', 'key' => 'card_opacity', 'value' => '1', 'type' => 'string', 'is_public' => true, 'label' => 'شفافیت کارت‌ها'], // Added
            ['group' => 'theme', 'key' => 'logo_url', 'value' => '', 'type' => 'string', 'is_public' => true, 'label' => 'لوگو'],
            ['group' => 'theme', 'key' => 'favicon_url', 'value' => '', 'type' => 'string', 'is_public' => true, 'label' => 'فاوآیکون'],
            ['group' => 'theme', 'key' => 'sidebar_collapsed', 'value' => false, 'type' => 'boolean', 'is_public' => true, 'label' => 'منوی کناری بصورت پیش‌فرض بسته باشد'],

            // تنظیمات امنیتی (جدید)
            ['group' => 'security', 'key' => 'max_login_attempts', 'value' => 5, 'type' => 'number', 'is_public' => false, 'label' => 'حداکثر تلاش ورود'],
            ['group' => 'security', 'key' => 'lockout_time', 'value' => 60, 'type' => 'number', 'is_public' => false, 'label' => 'زمان مسدودی (دقیقه)'],
            ['group' => 'security', 'key' => 'session_timeout', 'value' => 30, 'type' => 'number', 'is_public' => true, 'label' => 'تایم‌اوت نشست'],
            ['group' => 'security', 'key' => 'captcha_enabled', 'value' => false, 'type' => 'boolean', 'is_public' => true, 'label' => 'کپچا فعال باشد'],

            // تنظیمات باشگاه
            ['group' => 'club', 'key' => 'registration_points', 'value' => '50', 'type' => 'number', 'is_public' => false, 'label' => 'امتیاز ثبت نام'],
            ['group' => 'club', 'key' => 'referral_points', 'value' => '20', 'type' => 'number', 'is_public' => false, 'label' => 'امتیاز معرفی'],
            ['group' => 'club', 'key' => 'daily_point_limit', 'value' => '1000', 'type' => 'number', 'is_public' => false, 'label' => 'سقف امتیاز روزانه'],
            ['group' => 'finance', 'key' => 'currency', 'value' => 'تومان', 'type' => 'string', 'is_public' => true, 'label' => 'واحد پول'],
            ['group' => 'finance', 'key' => 'point_to_currency_rate', 'value' => '100', 'type' => 'number', 'is_public' => true, 'label' => 'ارزش هر امتیاز (به واحد پول)'],
            ['group' => 'finance', 'key' => 'allow_points_to_wallet', 'value' => '1', 'type' => 'boolean', 'is_public' => true, 'label' => 'تبدیل امتیاز به کیف پول مجاز است'],
            ['group' => 'finance', 'key' => 'allow_wallet_to_points', 'value' => '1', 'type' => 'boolean', 'is_public' => true, 'label' => 'تبدیل کیف پول به امتیاز مجاز است'],

            // تنظیمات پیامک
            ['group' => 'sms', 'key' => 'sms_provider', 'value' => 'kavenegar', 'type' => 'string', 'is_public' => false, 'label' => 'سرویس دهنده پیامک'],
            ['group' => 'sms', 'key' => 'sms_api_key', 'value' => '', 'type' => 'string', 'is_public' => false, 'label' => 'کلید API پیامک'],
            ['group' => 'sms', 'key' => 'sms_username', 'value' => '', 'type' => 'string', 'is_public' => false, 'label' => 'نام کاربری پنل پیامک'],
            ['group' => 'sms', 'key' => 'sms_password', 'value' => '', 'type' => 'string', 'is_public' => false, 'label' => 'رمز عبور پنل پیامک'],
            ['group' => 'sms', 'key' => 'sms_sender', 'value' => '10002000', 'type' => 'string', 'is_public' => false, 'label' => 'شماره فرستنده پیامک'],
            ['group' => 'sms', 'key' => 'resend_interval', 'value' => 120, 'type' => 'number', 'is_public' => true, 'label' => 'فاصله ارسال مجدد (ثانیه)'],
            ['group' => 'sms', 'key' => 'sms_ir_template_id', 'value' => '', 'type' => 'string', 'is_public' => false, 'label' => 'شناسه قالب SMS.ir'],
            ['group' => 'sms', 'key' => 'sms_ir_parameter_name', 'value' => 'Code', 'type' => 'string', 'is_public' => false, 'label' => 'نام پارامتر SMS.ir'],

            // تنظیمات درگاه پرداخت
            ['group' => 'payment', 'key' => 'payment_gateway', 'value' => 'zarinpal', 'type' => 'string', 'is_public' => false, 'label' => 'درگاه پرداخت پیش‌فرض'],
            ['group' => 'payment', 'key' => 'payment_merchant_id', 'value' => '', 'type' => 'string', 'is_public' => false, 'label' => 'مرچنت کد / ترمینال آی‌دی'],
            ['group' => 'payment', 'key' => 'payment_username', 'value' => '', 'type' => 'string', 'is_public' => false, 'label' => 'نام کاربری درگاه'],
            ['group' => 'payment', 'key' => 'payment_password', 'value' => '', 'type' => 'string', 'is_public' => false, 'label' => 'رمز عبور درگاه'],
            ['group' => 'payment', 'key' => 'payment_api_key', 'value' => '', 'type' => 'string', 'is_public' => false, 'label' => 'کلید API درگاه'],
            ['group' => 'payment', 'key' => 'payment_sandbox', 'value' => '1', 'type' => 'boolean', 'is_public' => false, 'label' => 'محیط سندباکس'],

            // تنظیمات اتصال به وردپرس
            ['group' => 'wordpress', 'key' => 'wp_url', 'value' => '', 'type' => 'string', 'is_public' => false, 'label' => 'آدرس سایت وردپرس'],
            ['group' => 'wordpress', 'key' => 'wp_consumer_key', 'value' => '', 'type' => 'string', 'is_public' => false, 'label' => 'Consumer Key (WooCommerce)'],
            ['group' => 'wordpress', 'key' => 'wp_consumer_secret', 'value' => '', 'type' => 'string', 'is_public' => false, 'label' => 'Consumer Secret (WooCommerce)'],
        ];

        foreach ($settings as $setting) {
            SystemSetting::updateOrCreate(
                ['group' => $setting['group'], 'key' => $setting['key']],
                $setting
            );
        }
    }
}
