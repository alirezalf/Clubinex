<!DOCTYPE html>
<html lang="fa" dir="rtl">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="robots" content="index, follow">
        <meta name="theme-color" content="<?php echo e($themeSettings['primary_color'] ?? '#0284c7'); ?>">


        <title inertia><?php echo e(config('app.name', 'Clubinex')); ?></title>
        <meta name="description" content="<?php echo e($site['description'] ?? 'باشگاه مشتریان پیشرفته با امکانات گیمیفیکیشن و فروشگاه جوایز'); ?>">
        <meta name="keywords" content="<?php echo e(\App\Models\SystemSetting::getValue('seo', 'meta_keywords') ?? 'باشگاه مشتریان, وفاداری, گیمیفیکیشن, جوایز'); ?>">
        <meta name="author" content="Clubinex Team">
        <link rel="canonical" href="<?php echo e(url()->current()); ?>">

        <!-- Open Graph / Facebook -->
        <meta property="og:type" content="website">
        <meta property="og:url" content="<?php echo e(url()->current()); ?>">
        <meta property="og:title" content="<?php echo e(config('app.name', 'Clubinex')); ?>">
        <meta property="og:description" content="<?php echo e($site['description'] ?? ''); ?>">
        <meta property="og:image" content="<?php echo e(\App\Models\SystemSetting::getValue('seo', 'og_image') ?? asset('images/og-default.jpg')); ?>">
        <meta property="og:locale" content="fa_IR">
        <meta property="og:site_name" content="<?php echo e($site['name'] ?? 'Clubinex'); ?>">

        <!-- Twitter -->
        <meta property="twitter:card" content="summary_large_image">
        <meta property="twitter:url" content="<?php echo e(url()->current()); ?>">
        <meta property="twitter:title" content="<?php echo e(config('app.name', 'Clubinex')); ?>">
        <meta property="twitter:description" content="<?php echo e($site['description'] ?? ''); ?>">
        <meta property="twitter:image" content="<?php echo e(\App\Models\SystemSetting::getValue('seo', 'og_image') ?? asset('images/og-default.jpg')); ?>">


        <?php if(isset($site['favicon'])): ?>
            <link rel="icon" href="<?php echo e($site['favicon']); ?>">
        <?php endif; ?>

        <link rel="manifest" href="/manifest.json">
        <script>
            if ('serviceWorker' in navigator) {
                window.addEventListener('load', () => {
                    navigator.serviceWorker.register('/sw.js');
                });
            }
        </script>

        <!-- Fonts -->
        <!-- Vazirmatn is imported via resources/css/app.css -->

        <!-- Dynamic Theme Styles -->
        <style>
            :root {
                /* محاسبات رنگ در AppServiceProvider انجام شده است */
                --color-primary-50: rgb(<?php echo e($themeSettings['primary_rgb'] ?? '2 132 199'); ?> / 0.05);
                --color-primary-100: rgb(<?php echo e($themeSettings['primary_rgb'] ?? '2 132 199'); ?> / 0.1);
                --color-primary-200: rgb(<?php echo e($themeSettings['primary_rgb'] ?? '2 132 199'); ?> / 0.2);
                --color-primary-300: rgb(<?php echo e($themeSettings['primary_rgb'] ?? '2 132 199'); ?> / 0.3);
                --color-primary-400: rgb(<?php echo e($themeSettings['primary_rgb'] ?? '2 132 199'); ?> / 0.5);
                --color-primary-500: <?php echo e($themeSettings['primary_color'] ?? '#0284c7'); ?>; /* Main Color */
                --color-primary-600: color-mix(in srgb, <?php echo e($themeSettings['primary_color'] ?? '#0284c7'); ?>, black 10%);
                --color-primary-700: color-mix(in srgb, <?php echo e($themeSettings['primary_color'] ?? '#0284c7'); ?>, black 20%);
                --color-primary-800: color-mix(in srgb, <?php echo e($themeSettings['primary_color'] ?? '#0284c7'); ?>, black 30%);
                --color-primary-900: color-mix(in srgb, <?php echo e($themeSettings['primary_color'] ?? '#0284c7'); ?>, black 40%);

                --radius-xl: <?php echo e($themeSettings['radius_size'] ?? '0.75rem'); ?>;
                --radius-2xl: calc(<?php echo e($themeSettings['radius_size'] ?? '0.75rem'); ?> + 0.25rem);

                /* New Variables for Theme Customization */
                --sidebar-bg: <?php echo e($themeSettings['sidebar_bg'] ?? '#ffffff'); ?>;
                --sidebar-text: <?php echo e($themeSettings['sidebar_text'] ?? '#1f2937'); ?>;
                --header-bg: <?php echo e($themeSettings['header_bg'] ?? 'rgba(255,255,255,0.8)'); ?>;
            }
        </style>

        <?php echo app('Tighten\Ziggy\BladeRouteGenerator')->generate(); ?>
        <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.tsx', "resources/js/Pages/{$page['component']}.tsx"]); ?>
        <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->head; } ?>
<?php
    $organizationData = [
        "@context" => "https://schema.org",
        "@type" => "Organization",
        "name" => $site['name'] ?? 'Clubinex',
        "url" => url('/'),
        "logo" => $site['logo'] ?? '',
        "contactPoint" => [
            "@type" => "ContactPoint",
            "telephone" => $site['contact']['phone'] ?? '',
            "contactType" => "customer service"
        ]
    ];
?>

<script type="application/ld+json">
    <?php echo json_encode($organizationData, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>

</script>

        
    </head>
    <body class="font-sans antialiased bg-gray-50 text-gray-800">
        <?php if (!isset($__inertiaSsrDispatched)) { $__inertiaSsrDispatched = true; $__inertiaSsrResponse = app(\Inertia\Ssr\Gateway::class)->dispatch($page); }  if ($__inertiaSsrResponse) { echo $__inertiaSsrResponse->body; } elseif (config('inertia.use_script_element_for_initial_page')) { ?><script data-page="app" type="application/json"><?php echo json_encode($page); ?></script><div id="app"></div><?php } else { ?><div id="app" data-page="<?php echo e(json_encode($page)); ?>"></div><?php } ?>
    </body>
</html><?php /**PATH D:\clubinex\resources\views/app.blade.php ENDPATH**/ ?>